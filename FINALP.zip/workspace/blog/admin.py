from django.contrib import admin
from .models import Post,Org, Address, Event

# Register your models here.
admin.site.register(Post)
admin.site.register(Org)
admin.site.register(Address)
admin.site.register(Event)