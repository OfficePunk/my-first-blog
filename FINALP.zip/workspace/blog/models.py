from __future__ import unicode_literals
from django.db import models
from django.utils import timezone


class Post(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    text = models.TextField()
    pic = models.ImageField(default='', upload_to="img_posts/", blank=True, verbose_name="picture")
    address = models.ForeignKey('Address')
    created_date = models.DateTimeField(
            default=timezone.now)
    published_date = models.DateTimeField(
            blank=True, null=True)

    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title
        

class Org(models.Model):
    
    name = models.CharField(max_length=200)
    coordinator = models.CharField(max_length = 200)
    description = models.TextField(default='')
    contacts = models.TextField(default='')
    address = models.ForeignKey('Address')
    
    def __str__(self):
        return self.name

class Event(models.Model):
    address = models.ForeignKey('Address')
    description = models.TextField(default='')
    name = models.CharField(max_length=500)
    image = models.ImageField(default='', upload_to="img_events/", blank=True, verbose_name="picture")
    organizator = models.ForeignKey('Org')
    gs = models.TextField(default='')
    go = models.TextField(default='')
    contacts = models.TextField(default='')
    etype = models.CharField(max_length=200)
    created_date = models.DateTimeField(default=timezone.now)
    edate = models.DateTimeField(blank=True, null=True)

class Address(models.Model):
    
    description = models.TextField(default='sdu')
    longitude = models.DecimalField(default='', max_digits=9, decimal_places=6)
    lattitude = models.DecimalField(default='', max_digits=9, decimal_places=6)
    
    def __str__(self):
        return self.description        