from django.conf.urls import url, include
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf import settings

from core import views as core_views
from blog import views as bviews

urlpatterns = [
    #url(r'^$', bviews.homepage, name='homepage'),
    url(r'^homepage$', bviews.homepage, name='homepage'),
     url(r'^profile$', bviews.profile, name='myprofile'),
    url(r'^$', core_views.home, name='home'),
    url(r'^login/$', auth_views.login, name='login'),
    url(r'^logout/$', auth_views.logout, name='logout'),
    url(r'^signup/$', core_views.signup, name='signup'),
    url(r'^useful_info/$', bviews.useful_info, name='useful_info'),
    url(r'^settings/$', core_views.settings, name='settings'),
    url(r'^settings/password/$', core_views.password, name='password'),
    url(r'^oauth/', include('social_django.urls', namespace='social')),
    url(r'^admin/', admin.site.urls),
    url(r'^blog/$', bviews.blog, name = 'blog'),
    url(r'^test/$', bviews.test, name = 'test')
    ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

